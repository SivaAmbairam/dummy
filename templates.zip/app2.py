import signal
import time
from flask import Flask, render_template, request, jsonify, send_from_directory
from threading import Thread
import threading
import subprocess
import os
import logging
import jaydebeapi
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from scheduler import schedule_task, stop_scheduled_task, get_scheduled_tasks, schedule_monthly_task, scheduled_tasks

app = Flask(__name__)


SCRIPTS_DIRECTORY = r"C:\Users\G6\PycharmProjects\WebScrappingWebPage\Scrapping Scripts"
COMPARISON_SCRIPT = r"C:\Users\G6\PycharmProjects\WebScrappingWebPage\Run_script"
FISHER_COMPARISON_SCRIPT = r'C:\Users\G6\PycharmProjects\WebScrappingWebPage\Fisher_Script'

logging.basicConfig(level=logging.DEBUG)

jdbc_driver_dir = r'C:\Users\G6\Downloads\sqljdbc_12.6\enu\jars'
jdbc_driver_jar = 'mssql-jdbc-12.6.3.jre8.jar'
jdbc_driver_path = os.path.join(jdbc_driver_dir, jdbc_driver_jar)
jdbc_driver_class = 'com.microsoft.sqlserver.jdbc.SQLServerDriver'
server = 'FSI-FSQL3-PROD'


def get_connection(username, password, schema):
    connection_url = f'jdbc:sqlserver://{server};databaseName={schema};encrypt=true;trustServerCertificate=true;integratedSecurity=true;'
    connection_properties = {
        'user': username,
        'password': password,
        'integratedSecurity': 'true',
        'authenticationScheme': 'NTLM',
        'domain': 'fsi'
    }
    try:
        connection = jaydebeapi.connect(
            jdbc_driver_class,
            connection_url,
            connection_properties,
            [jdbc_driver_path]
        )
        return connection
    except jaydebeapi.DatabaseError as e:
        logging.error(f"Error connecting to the database: {e}")
        return None


def stop_execution_handler(signum, frame):
    global stop_execution
    stop_execution = True


signal.signal(signal.SIGINT, stop_execution_handler)

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
SENDER_EMAIL = "webscraper86@gmail.com"
SENDER_PASSWORD = "tvwn fvav djgq xcvw"
RECIPIENT_EMAIL = "siva2000a@gmail.com"

def send_email(subject, body):
    message = MIMEMultipart()
    message["From"] = SENDER_EMAIL
    message["To"] = RECIPIENT_EMAIL
    message["Subject"] = subject
    message.attach(MIMEText(body, "plain"))

    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SENDER_EMAIL, SENDER_PASSWORD)
            server.send_message(message)
        logging.info(f"Email sent: {subject}")
    except Exception as e:
        logging.error(f"Failed to send email: {e}")

@app.route('/send_email', methods=['POST'])
def email_endpoint():
    data = request.json
    subject = data.get('subject')
    body = data.get('body')
    send_email(subject, body)
    return jsonify({"message": "Email sent successfully"}), 200

stop_execution = False
script_status = {}
script_output = {}


def run_script(script_name):
    global stop_execution, script_status, script_output
    script_path = os.path.join(SCRIPTS_DIRECTORY, script_name)
    script_status[script_name] = 'Running'
    url_count = 0
    def check_and_run_comparison():
        all_completed = all(
            status.startswith('Completed') for script, status in script_status.items() if script != 'push_script.py')
        if all_completed:
            logging.debug("All scripts completed. Starting push_script.py.")
            run_script('push_script.py')

    try:
        logging.debug(f"Starting script: {script_name}")
        process = subprocess.Popen(['python', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   universal_newlines=True)
        while True:
            if stop_execution or script_status[script_name] == 'Stopping':
                logging.debug(f"Stopping script: {script_name}")
                process.terminate()
                process.wait(timeout=5)
                if process.poll() is None:
                    process.kill()
                script_status[script_name] = f'Stopped (URLs scraped: {url_count})'
                break
            try:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    logging.debug(f'Script {script_name} output: {output.strip()}')
                    script_output[script_name] = script_output.get(script_name, '') + output
                    if output.strip().startswith('https://'):  # Count URLs
                        url_count += 1
                        script_status[script_name] = f'Running (URLs scraped: {url_count})'
            except subprocess.TimeoutExpired:
                continue

        stdout, stderr = process.communicate()
        script_output[script_name] = script_output.get(script_name, '') + stdout + stderr
        rc = process.poll()

        if rc == 0:
            script_status[script_name] = f'Completed (URLs scraped: {url_count})'
            check_and_run_comparison()
        else:
            script_status[script_name] = f'Error: {stderr.strip()}'

    except Exception as e:
        logging.error(f"Exception running script {script_name}: {e}")
        script_status[script_name] = f'Error: {str(e)}'

    finally:
        if script_status[script_name].startswith('Running'):
            script_status[script_name] = f'Completed (URLs scraped: {url_count})'
            check_and_run_comparison()

    return script_status[script_name].startswith('Completed')


@app.route('/run_comparison', methods=['POST'])
def run_comparison():
    global stop_execution, script_status, script_output
    script_name = request.form.get('scripts')
    script_path = os.path.join(COMPARISON_SCRIPT, script_name)
    script_status[script_name] = 'Running'

    try:
        logging.debug(f"Starting script: {script_name}")
        # Use a buffer to enable real-time output reading
        process = subprocess.Popen(['python', script_path],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE,
                                   bufsize=1,
                                   universal_newlines=True)

        while True:
            if stop_execution or script_status[script_name] == 'Stopping':
                logging.debug(f"Stopping script: {script_name}")
                process.terminate()
                process.wait(timeout=5)
                if process.poll() is None:
                    process.kill()
                script_status[script_name] = 'Stopped'
                break

            # Read output line by line
            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                # Print to console
                print(f'Script {script_name} output: {output.strip()}')
                # Log the output
                logging.debug(f'Script {script_name} output: {output.strip()}')
                script_output[script_name] = script_output.get(script_name, '') + output
                script_status[script_name] = 'Running'

        # Capture any remaining output
        stdout, stderr = process.communicate(timeout=5)
        if stdout:
            print(f'Script {script_name} final stdout: {stdout}')
            logging.debug(f'Script {script_name} final stdout: {stdout}')
        if stderr:
            print(f'Script {script_name} final stderr: {stderr}')
            logging.error(f'Script {script_name} final stderr: {stderr}')

        script_output[script_name] = script_output.get(script_name, '') + stdout + stderr
        rc = process.poll()

        if rc == 0:
            script_status[script_name] = 'Completed'
        else:
            script_status[script_name] = f'Error: {stderr.strip()}'

    except Exception as e:
        logging.error(f"Exception running script {script_name}: {e}")
        print(f"Exception running script {script_name}: {e}")
        script_status[script_name] = f'Error: {str(e)}'

    finally:
        if script_status[script_name].startswith('Running'):
            script_status[script_name] = 'Completed'

    return jsonify({script_name: script_status[script_name]})

# @app.route('/run_comparison', methods=['POST'])
# def run_comparison():
#     global stop_execution, script_status, script_output
#     script_name = request.form.get('scripts')
#     script_path = os.path.join(COMPARISON_SCRIPT, script_name)
#     script_status[script_name] = 'Running'
#
#     try:
#         logging.debug(f"Starting script: {script_name}")
#         process = subprocess.Popen(['python', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
#                                    universal_newlines=True)
#
#         while True:
#             if stop_execution or script_status[script_name] == 'Stopping':
#                 logging.debug(f"Stopping script: {script_name}")
#                 process.terminate()
#                 process.wait(timeout=5)
#                 if process.poll() is None:
#                     process.kill()
#                 script_status[script_name] = 'Stopped'
#                 break
#
#             output = process.stdout.readline()
#             if output == '' and process.poll() is not None:
#                 break
#             if output:
#                 logging.debug(f'Script {script_name} output: {output.strip()}')
#                 script_output[script_name] = script_output.get(script_name, '') + output
#                 script_status[script_name] = 'Running'
#
#         stdout, stderr = process.communicate(timeout=5)
#         script_output[script_name] = script_output.get(script_name, '') + stdout + stderr
#         rc = process.poll()
#
#         if rc == 0:
#             script_status[script_name] = 'Completed'
#         else:
#             script_status[script_name] = f'Error: {stderr.strip()}'
#
#     except Exception as e:
#         logging.error(f"Exception running script {script_name}: {e}")
#         script_status[script_name] = f'Error: {str(e)}'
#
#     finally:
#         if script_status[script_name].startswith('Running'):
#             script_status[script_name] = 'Completed'
#
#     return jsonify({script_name: script_status[script_name]})

@app.route('/run_comparison_v1', methods=['POST'])
def run_comparison_v1():
    global stop_execution, script_status, script_output
    script_name = request.form.get('scripts')
    script_path = os.path.join(FISHER_COMPARISON_SCRIPT, script_name)
    script_status[script_name] = 'Running'
    try:
        logging.debug(f"Starting script: {script_name}")
        process = subprocess.Popen(['python', script_path], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   universal_newlines=True)

        while True:
            if stop_execution or script_status[script_name] == 'Stopping':
                logging.debug(f"Stopping script: {script_name}")
                process.terminate()
                process.wait(timeout=5)
                if process.poll() is None:
                    process.kill()
                script_status[script_name] = 'Stopped'
                break

            output = process.stdout.readline()
            if output == '' and process.poll() is not None:
                break
            if output:
                logging.debug(f'Script {script_name} output: {output.strip()}')
                script_output[script_name] = script_output.get(script_name, '') + output
                script_status[script_name] = 'Running'

        stdout, stderr = process.communicate(timeout=5)
        script_output[script_name] = script_output.get(script_name, '') + stdout + stderr
        rc = process.poll()

        if rc == 0:
            script_status[script_name] = 'Completed'
        else:
            script_status[script_name] = f'Error: {stderr.strip()}'

    except Exception as e:
        logging.error(f"Exception running script {script_name}: {e}")
        script_status[script_name] = f'Error: {str(e)}'

    finally:
        if script_status[script_name].startswith('Running'):
            script_status[script_name] = 'Completed'

    return jsonify({script_name: script_status[script_name]})


UNWANTED_SCRIPTS = ['module_package.py', 'push_script.py']


@app.route('/')
def index():
    try:
        scripts = [f for f in os.listdir(SCRIPTS_DIRECTORY) if f.endswith('.py') and f not in UNWANTED_SCRIPTS]
        return render_template('index.html', scripts=scripts)
    except Exception as e:
        logging.error(f"Error loading scripts: {str(e)}")
        return jsonify({'status': f'Error loading scripts: {str(e)}'}), 500


@app.route('/settings')
def settings():
    return render_template('settings.html')


@app.route('/run_scripts', methods=['POST'])
def run_scripts():
    try:
        global stop_execution
        stop_execution = False
        scripts = request.form.getlist('scripts')
        if not scripts:
            return jsonify({'status': 'No scripts selected.'})
        for script in scripts:
            threading.Thread(target=run_script, args=(script,)).start()
            update_task_status(script, 'Running')  # Add this line
        return jsonify({'status': 'Scripts running...'})
    except Exception as e:
        logging.error(f"Error running scripts: {str(e)}")
        return jsonify({'status': f'Error running scripts: {str(e)}'}), 500


def update_task_status(script_name, status):
    for task in scheduled_tasks:
        if task['script_name'] == script_name:
            task['status'] = status
            break


@app.route('/stop_scripts', methods=['POST'])
def stop_scripts():
    try:
        global stop_execution, script_status
        stop_execution = True
        # Terminate all running scripts
        for script_name, status in script_status.items():
            if status == 'Running':
                script_status[script_name] = 'Stopping'
        return jsonify({'status': 'Stopping all running scripts...'})
    except Exception as e:
        logging.error(f"Error stopping scripts: {str(e)}")
        return jsonify({'status': f'Error stopping scripts: {str(e)}'}), 500


@app.route('/status', methods=['GET'])
def status():
    try:
        return jsonify(script_status)
    except Exception as e:
        logging.error(f"Error getting status: {str(e)}")
        return jsonify({'status': f'Error getting status: {str(e)}'}), 500


@app.route('/schedule_scripts', methods=['POST'])
def schedule_scripts():
    global stop_execution
    try:
        stop_execution = False  # Reset the stop_execution flag when scheduling
        scripts = request.form.getlist('scripts')
        start_date = request.form.get('start-date')
        start_time = request.form.get('start-time')
        recurrence_type = request.form.get('recurrence-type')

        unique_scripts = list(set(scripts))
        scheduled_scripts = []

        for script in unique_scripts:
            if recurrence_type == 'monthly':
                schedule_monthly_task(script, start_date, start_time, run_script)
            else:
                schedule_task(script, start_date, start_time, run_script)
            scheduled_scripts.append(script)

        if recurrence_type == 'monthly':
            status = f'Scheduled {scheduled_scripts} monthly from {start_date} at {start_time}'
        else:
            status = f'Scheduled {scheduled_scripts} for {start_date} at {start_time}'

        return jsonify({'status': status})
    except Exception as e:
        logging.error(f"Error scheduling script: {str(e)}")
        return jsonify({'status': f'Error scheduling script: {str(e)}'}), 500

@app.route('/stop_scheduled_scripts', methods=['POST'])
# def stop_scheduled_scripts():
#     try:
#         script_name = request.form.get('script_name')
#         if not script_name:
#             return jsonify({'status': 'No script name provided.'}), 400
#         response = stop_scheduled_task(script_name)
#         return response
#     except Exception as e:
#         logging.error(f"Error stopping scheduled task: {str(e)}")
#         return jsonify({'status': f'Error stopping scheduled task: {str(e)}'}), 500


@app.route('/stop_scheduled_scripts', methods=['POST'])
def stop_scheduled_scripts():
    try:
        response = stop_scheduled_task()
        return response
    except Exception as e:
        logging.error(f"Error stopping scheduled tasks: {str(e)}")
        return jsonify({'status': f'Error stopping scheduled tasks: {str(e)}'}), 500


@app.route('/reset_state', methods=['POST'])
def reset_state():
    global stop_execution, script_status, script_output
    stop_execution = False
    script_status = {}
    script_output = {}
    return jsonify({'status': 'State reset successfully'})


@app.route('/stop_all', methods=['POST'])
def stop_all():
    global stop_execution, script_status, scheduled_tasks
    try:
        stop_execution = True
        for script_name in script_status:
            script_status[script_name] = 'Stopped'

        stop_scheduled_task()

        scheduled_tasks.clear()

        return jsonify({'status': 'All scheduled tasks and running scripts have been stopped.'})
    except Exception as e:
        return jsonify({'status': f'Error stopping all tasks and scripts: {str(e)}'}), 500


@app.route('/get_scheduling_status', methods=['GET'])
def get_scheduling_status():
    tasks = get_scheduled_tasks()
    any_scheduled = len(tasks) > 0
    any_running = any(task.get('status') == 'Running' for task in tasks)
    return jsonify({
        'status': 'Scheduled' if any_scheduled else 'Not Scheduled',
        'tasks': [{'script_name': task['script_name'], 'run_date': task['run_date'], 'run_time': task['run_time'],
                   'status': task.get('status', 'Scheduled')} for task in tasks],
        'any_scheduled': any_scheduled,
        'any_running': any_running
    })

@app.route('/check_running_scripts', methods=['GET'])
def check_running_scripts():
    any_running = any(status == 'Running' for status in script_status.values())
    return jsonify({'any_running': any_running})


@app.route('/get_scheduled_tasks', methods=['GET'])
def get_scheduled_tasks_route():
    try:
        tasks = get_scheduled_tasks()
        return jsonify(tasks)
    except Exception as e:
        logging.error(f"Error getting scheduled tasks: {str(e)}")
        return jsonify({'status': f'Error getting scheduled tasks: {str(e)}'}), 500


@app.route('/styles.css')
def styles():
    return send_from_directory('static', 'styles.css')


@app.route('/writefile', methods=['POST'])
def write_visited_log():
    data = request.get_json()
    if data:
        formatted_data = f"user-name: {data['user-name']}\npassword: {data['password']}\nschema: {data['schema']}\n"
        output_directory = os.path.join(SCRIPTS_DIRECTORY, 'Output', 'temp')
        file_path = os.path.join(output_directory, 'db_connection_file.txt')
        os.makedirs(output_directory, exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(formatted_data)
        return jsonify({"message": "Data written successfully"}), 200
    else:
        return jsonify({"error": "No data received"}), 400


@app.route('/db_connection', methods=['POST'])
def db_connection():
    try:
        username = request.form.get('user-name')
        password = request.form.get('password')
        schema = request.form.get('schema')

        connection = get_connection(username, password, schema)
        if connection:
            cursor = connection.cursor()
            cursor.execute("SELECT @@version;")
            row = cursor.fetchone()
            version_info = row[0] if row else "Unknown"
            cursor.close()
            connection.close()
            return jsonify({'status': 'success', 'version': version_info})
        else:
            return jsonify({'status': 'failed', 'error': 'Unable to connect to the database'}), 500
    except Exception as e:
        logging.error(f"Error in connection: {str(e)}")
        return jsonify({'status': f'Error in connection: {str(e)}'}), 500


if __name__ == '__main__':
    app.run(host='192.168.0.91', port=5000, debug=True)
